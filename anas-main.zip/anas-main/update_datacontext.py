import re

with open('frontend/src/context/DataContext.tsx', 'r') as f:
    content = f.read()

# Replace the type definition
pattern1 = r"navigationIntent: \{ view: string; action\?: string; driverId\?: string; truckId\?: string; tab\?: string; returnTo\?: string; returnData\?: any; \} \| null;"
replacement1 = "navigationIntent: { view: string; action?: string; driverId?: string; truckId?: string; tab?: string; returnTo?: string; returnData?: any; searchQuery?: string; } | null;"
content = re.sub(pattern1, replacement1, content)

pattern2 = r"setNavigationIntent: React.Dispatch<React.SetStateAction<\{ view: string; action\?: string; driverId\?: string; truckId\?: string; tab\?: string; returnTo\?: string; returnData\?: any; \} \| null>>;"
replacement2 = "setNavigationIntent: React.Dispatch<React.SetStateAction<{ view: string; action?: string; driverId?: string; truckId?: string; tab?: string; returnTo?: string; returnData?: any; searchQuery?: string; } | null>>;"
content = re.sub(pattern2, replacement2, content)

pattern3 = r"const \[navigationIntent, setNavigationIntent\] = useState<\{\n\s*view: string;\n\s*action\?: string;\n\s*driverId\?: string;\n\s*truckId\?: string;\n\s*tab\?: string;\n\s*returnTo\?: string;\n\s*returnData\?: any;\n\s*\} \| null>\(null\);"
replacement3 = """  const [navigationIntent, setNavigationIntent] = useState<{
    view: string;
    action?: string;
    driverId?: string;
    truckId?: string;
    tab?: string;
    returnTo?: string;
    returnData?: any;
    searchQuery?: string;
  } | null>(null);"""
content = re.sub(pattern3, replacement3, content)

with open('frontend/src/context/DataContext.tsx', 'w') as f:
    f.write(content)
