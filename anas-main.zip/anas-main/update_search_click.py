import re

def rewrite_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()
    
    # We need to import useData if it's not already, wait, both components already have useData().
    # Let's verify:
    # `const { loads, drivers, trucks, customers, locations, invoices, theme } = useData();`
    # Replace it to include setNavigationIntent.
    
    pattern1 = r"const \{ (.*?) \} = useData\(\);"
    def replacer1(m):
        inner = m.group(1)
        if "setNavigationIntent" not in inner:
            return f"const {{ {inner}, setNavigationIntent }} = useData();"
        return m.group(0)
    
    content = re.sub(pattern1, replacer1, content)
    
    # Replace handleSelect switch statement
    handle_select_pattern = r"  const handleSelect = \(item: any, type: string\) => \{.*?switch \(type\) \{.*?\}\n  \};"
    
    replacement = """  const handleSelect = (item: any, type: string) => {
    if (typeof setIsOpen === 'function') setIsOpen(false);
    if (typeof setQuery === 'function') setQuery('');
    
    switch (type) {
      case 'load': 
        navigate('loads', item.id); 
        break;
      case 'driver': 
        setNavigationIntent({ view: 'assets', tab: 'Drivers', searchQuery: item.name });
        navigate('assets'); 
        break;
      case 'truck': 
        setNavigationIntent({ view: 'assets', tab: 'Trucks', searchQuery: item.unitNumber });
        navigate('assets'); 
        break;
      case 'customer': 
        setNavigationIntent({ view: 'customers', searchQuery: item.name });
        navigate('customers'); 
        break;
      case 'location': 
        setNavigationIntent({ view: 'locations', searchQuery: item.name });
        navigate('locations'); 
        break;
      case 'invoice': 
        setNavigationIntent({ view: 'invoices', searchQuery: item.invoiceNumber });
        navigate('invoices'); 
        break;
      case 'settlement': 
        setNavigationIntent({ view: 'settlements', searchQuery: item.settlementNumber });
        navigate('settlements'); 
        break;
    }
  };"""
    
    content = re.sub(handle_select_pattern, replacement, content, flags=re.DOTALL)
    
    with open(filepath, 'w') as f:
        f.write(content)

rewrite_file('frontend/src/components/layout/GlobalSearch.tsx')
rewrite_file('frontend/src/views/SearchResultsView.tsx')
