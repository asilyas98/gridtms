import re

with open('frontend/src/views/InvoicesView.tsx', 'r') as f:
    content = f.read()

pattern = r"(<p className=\"text-sm text-slate-500\">Track receivables and customer payment status\.</p>\n\s*<\/div>)"

replacement = r"""\1
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Search invoices..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 transition-colors w-64"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </div>"""

content = re.sub(pattern, replacement, content)

# I also need to ensure Search is imported in InvoicesView if not already. Let's check imports.
# `import { ..., Search, ... } from 'lucide-react'`
import_pattern = r"import \{\s*([^}]*)\s*\} from 'lucide-react';"
def add_search_import(match):
    inner = match.group(1)
    if 'Search' not in inner:
        return f"import {{ {inner}, Search }} from 'lucide-react';"
    return match.group(0)

content = re.sub(import_pattern, add_search_import, content)

with open('frontend/src/views/InvoicesView.tsx', 'w') as f:
    f.write(content)
