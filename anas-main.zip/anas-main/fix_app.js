const fs = require('fs');
let code = fs.readFileSync('frontend/src/App.tsx', 'utf8');

// replace DataContext usage to include navigationIntent
code = code.replace(
  `const { theme, companySettings } = useData();`,
  `const { theme, companySettings, navigationIntent: contextNavIntent, setNavigationIntent: setContextNavIntent } = useData();`
);

code = code.replace(
  `React.useEffect(() => {
    if (navigationIntent && navigationIntent.view) {
      setCurrentView(navigationIntent.view);
    }
  }, [navigationIntent]);`,
  `React.useEffect(() => {
    if (navigationIntent && navigationIntent.view) {
      setCurrentView(navigationIntent.view);
    }
  }, [navigationIntent]);
  
  React.useEffect(() => {
    if (contextNavIntent && contextNavIntent.view) {
      setCurrentView(contextNavIntent.view);
      // We don't necessarily clear it immediately here, let the view consume it, 
      // or we can clear it if it's purely a navigation trigger. 
      // Wait, let's just use it to set currentView.
    }
  }, [contextNavIntent]);`
);
fs.writeFileSync('frontend/src/App.tsx', code);
