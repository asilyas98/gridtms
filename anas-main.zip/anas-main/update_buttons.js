const fs = require('fs');
let code = fs.readFileSync('frontend/src/components/loads/LoadWizard.tsx', 'utf8');

if (!code.includes('Plus,')) {
  code = code.replace(/import {([^}]+)} from 'lucide-react';/, (match, p1) => {
    return `import { Plus, ${p1.trim()} } from 'lucide-react';`;
  });
}

code = code.replace(
  `<button type="button" onClick={handleAddCustomer} className="text-[10px] uppercase font-bold tracking-widest text-orange hover:underline">
                         + Add New Customer
                       </button>`,
  `<button type="button" onClick={handleAddCustomer} className="text-[10px] uppercase font-bold tracking-widest text-orange bg-orange/10 hover:bg-orange/20 px-3 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 w-full sm:w-auto">
                         <Plus size={14} /> Add New Customer
                       </button>`
);

code = code.replace(
  `<button type="button" onClick={handleAddOrigin} className="text-[10px] uppercase font-bold tracking-widest text-teal hover:underline">
                         + Add New Location
                       </button>`,
  `<button type="button" onClick={handleAddOrigin} className="text-[10px] uppercase font-bold tracking-widest text-teal bg-teal/10 hover:bg-teal/20 px-3 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 w-full sm:w-auto">
                         <Plus size={14} /> Add New Location
                       </button>`
);

code = code.replace(
  `<button type="button" onClick={handleAddDestination} className="text-[10px] uppercase font-bold tracking-widest text-rose-500 hover:underline">
                         + Add New Location
                       </button>`,
  `<button type="button" onClick={handleAddDestination} className="text-[10px] uppercase font-bold tracking-widest text-rose-500 bg-rose-500/10 hover:bg-rose-500/20 px-3 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 w-full sm:w-auto">
                         <Plus size={14} /> Add New Location
                       </button>`
);

fs.writeFileSync('frontend/src/components/loads/LoadWizard.tsx', code);
