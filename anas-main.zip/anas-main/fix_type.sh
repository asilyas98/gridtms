#!/bin/bash
sed -i 's/const { loads, drivers, trucks, customers, locations, invoices, settlements } = useData();/const { loads, drivers, trucks, customers, locations, invoices } = useData();\n  const settlements: any[] = [];/g' frontend/src/components/layout/GlobalSearch.tsx
