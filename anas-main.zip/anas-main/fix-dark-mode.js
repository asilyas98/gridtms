const fs = require('fs');
const cssPath = 'frontend/src/index.css';
let css = fs.readFileSync(cssPath, 'utf8');

if (!css.includes('@custom-variant dark')) {
    css = css.replace('@import "tailwindcss";', `@import "tailwindcss";\n@custom-variant dark (&:where(.dark, .dark *));`);
    fs.writeFileSync(cssPath, css);
    console.log('Fixed dark mode!');
} else {
    console.log('Already fixed!');
}
