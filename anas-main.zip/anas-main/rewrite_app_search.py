import re

with open('frontend/src/App.tsx', 'r') as f:
    content = f.read()

# 1. Add import
if "import GlobalSearch" not in content:
    content = content.replace(
        "import { DataProvider, useData } from './context/DataContext';",
        "import { DataProvider, useData } from './context/DataContext';\nimport GlobalSearch from './components/layout/GlobalSearch';"
    )

# 2. Replace static search bar with GlobalSearch component
search_block = r"""            \{\/\* Spotlight-inspired Capsule Search \*\/\}
            <div 
              title="Type a search query to filter active loads, customers, or routes"
              className=\{\`hidden sm:flex items-center gap-3 px-4 py-2 rounded-full w-48 lg:w-80 border focus-within:ring-2 focus-within:ring-blue-500\/10 focus-within:border-blue-500 transition-all \$\{
                theme === 'dark' \? 'bg-\[\#1C1C1E\]\/50 border-\[\#2D2D2D\]' : 'bg-slate-100\/80 border-slate-200\/80'
              \}\`\}
            >
              <Search size=\{14\} className="text-slate-400 shrink-0" \/>
              <input 
                type="text" 
                placeholder="Search operational records\.\.\." 
                className="bg-transparent border-none outline-none text-\[13px\] w-full placeholder-slate-400 font-sans" 
              \/>
            <\/div>"""

replacement = """            {/* Unified Global Search Component */}
            <GlobalSearch navigate={navigate} theme={theme} />"""

content = re.sub(search_block, replacement, content, flags=re.DOTALL)

with open('frontend/src/App.tsx', 'w') as f:
    f.write(content)
