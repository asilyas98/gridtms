import re

with open('frontend/src/views/SearchResultsView.tsx', 'r') as f:
    content = f.read()

# 1. Update Icons in SearchResultsView
content = content.replace("import { Search, PackageOpen, Users, Truck as TruckIcon, MapPin, FileText, Wallet, ChevronRight, LayoutList } from 'lucide-react';", 
"import { Search, PackageOpen, Users, Truck as TruckIcon, MapPin, FileText, Wallet, ChevronRight, LayoutList, Truck } from 'lucide-react';")

content = content.replace("icon: <PackageOpen size={16} />", "icon: <Truck size={16} />") # Match system (Loads = Truck)
# Keep Drivers = Users
# Keep Trucks = TruckIcon
# Keep Customers = Users
# Keep Locations = MapPin
# Keep Invoices = FileText

# 2. Update Typography for legibility
# text-slate-500 -> text-slate-600, dark:text-zinc-400 -> dark:text-slate-400
content = content.replace("text-slate-500 dark:text-zinc-400", "text-slate-600 dark:text-slate-300")
content = content.replace("text-slate-400 dark:text-zinc-500", "text-slate-500 dark:text-slate-400")

# 3. Increase font size slightly if it's too small
content = content.replace("text-[12px]", "text-[13px]")
content = content.replace("text-xs font-black", "text-xs font-bold")

with open('frontend/src/views/SearchResultsView.tsx', 'w') as f:
    f.write(content)

with open('frontend/src/components/layout/GlobalSearch.tsx', 'r') as f:
    content = f.read()

# Update icons in GlobalSearch to match System
content = content.replace("case 'load': return <PackageOpen size={16} className=\"text-orange\" />;", "case 'load': return <Truck size={16} className=\"text-orange\" />;")

# Update placeholder color for legibility
content = content.replace("placeholder-slate-400 font-sans text-slate-900", "placeholder-slate-500 dark:placeholder-slate-400 font-sans text-slate-900")

with open('frontend/src/components/layout/GlobalSearch.tsx', 'w') as f:
    f.write(content)
