import re

with open('frontend/src/views/InvoicesView.tsx', 'r') as f:
    content = f.read()

pattern = r"  const \[viewingDoc, setViewingDoc\] = React\.useState<any>\(null\);"
replacement = r"""  const [viewingDoc, setViewingDoc] = React.useState<any>(null);
  const [searchQuery, setSearchQuery] = React.useState('');
  const { navigationIntent, setNavigationIntent } = useData();

  React.useEffect(() => {
    if (navigationIntent && navigationIntent.view === 'invoices') {
      if (navigationIntent.searchQuery) {
        setSearchQuery(navigationIntent.searchQuery);
        // Automatically switch to All or clear active tab logic if needed, 
        // but we can just let it filter the current tab, or maybe we want to ignore tabs?
        // Let's just set the search query.
      }
      setNavigationIntent(null);
    }
  }, [navigationIntent, setNavigationIntent]);"""

content = re.sub(pattern, replacement, content)

pattern2 = r"  const filteredInvoices = invoices\.filter\(inv => \{\n    if \(activeTab === 'Open'\) return inv\.status === 'Sent' \|\| inv\.status === 'Draft' \|\| inv\.status === 'Partially Paid';\n    if \(activeTab === 'Overdue'\) return inv\.status === 'Overdue';\n    if \(activeTab === 'Rejected'\) return inv\.status === 'Rejected';\n    if \(activeTab === 'Disputed'\) return inv\.status === 'Disputed';\n    return inv\.status === 'Paid';\n  \}\);"
replacement2 = r"""  const filteredInvoices = invoices.filter(inv => {
    let matchesTab = false;
    if (activeTab === 'Open') matchesTab = inv.status === 'Sent' || inv.status === 'Draft' || inv.status === 'Partially Paid';
    else if (activeTab === 'Overdue') matchesTab = inv.status === 'Overdue';
    else if (activeTab === 'Rejected') matchesTab = inv.status === 'Rejected';
    else if (activeTab === 'Disputed') matchesTab = inv.status === 'Disputed';
    else matchesTab = inv.status === 'Paid';
    
    if (!matchesTab && !searchQuery) return false;
    
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchesSearch = inv.invoiceNumber.toLowerCase().includes(q) || 
                            getCustomerName(inv.customerId).toLowerCase().includes(q) || 
                            inv.loadId.toLowerCase().includes(q);
      // If there is a search query, show the invoice regardless of tab as long as it matches
      return matchesSearch;
    }
    
    return matchesTab;
  });"""

content = re.sub(pattern2, replacement2, content)

with open('frontend/src/views/InvoicesView.tsx', 'w') as f:
    f.write(content)
