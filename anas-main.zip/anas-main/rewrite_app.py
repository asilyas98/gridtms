import re

with open('frontend/src/App.tsx', 'r') as f:
    content = f.read()

# 1. Update imports
content = content.replace("import MobileNav from './components/layout/MobileNav';", "")
content = content.replace("import { motion } from 'motion/react';", "import { motion, AnimatePresence } from 'motion/react';")
content = content.replace(
"""import { 
  Search, 
  Bell, 
  HelpCircle 
} from 'lucide-react';""", 
"""import { 
  Search, 
  Bell, 
  HelpCircle,
  Menu,
  X
} from 'lucide-react';""")

# 2. Add state
content = content.replace(
    "const [selectedLoadId, setSelectedLoadId] = React.useState<string | null>(null);",
    """const [selectedLoadId, setSelectedLoadId] = React.useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);"""
)

# 3. Update navigate & handleNavClick to close sidebar
content = content.replace(
"""  const navigate = (view: string, loadId: string | null = null) => {
    setCurrentView(view);
    setSelectedLoadId(loadId);
  };""",
"""  const navigate = (view: string, loadId: string | null = null) => {
    setCurrentView(view);
    setSelectedLoadId(loadId);
    setIsSidebarOpen(false);
  };"""
)
content = content.replace(
"""  const handleNavClick = (view: string) => {
    setCurrentView(view);
    setSelectedLoadId(null);
  };""",
"""  const handleNavClick = (view: string) => {
    setCurrentView(view);
    setSelectedLoadId(null);
    setIsSidebarOpen(false);
  };"""
)

# 4. Update the main container and remove MobileNav
# Replace from `return (` up to `<MobileNav.../>`

main_structure = """  return (
    <div 
      className={`flex h-[100dvh] w-screen overflow-hidden relative transition-colors duration-300 ${
        theme === 'dark' ? 'dark bg-black text-slate-100' : 'bg-[#F5F5F7] text-slate-900'
      }`}
      style={{
        '--font-size-adjust': `${fontSizeAdjust}px`
      } as React.CSSProperties}
    >
      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      <motion.div 
        className={`fixed lg:sticky top-0 left-0 h-full z-50 select-none bg-transparent ${isSidebarOpen ? 'flex' : 'hidden lg:flex'}`}
        initial={false}
        animate={{ width: sidebarPinned || sidebarHovered || isSidebarOpen ? 260 : 72 }}
        transition={{ 
          duration: 0.2,
          ease: [0.25, 0.1, 0.25, 1.0] // Apple-like custom ease
        }}
      >
        <Sidebar 
          currentView={currentView} 
          setCurrentView={handleNavClick} 
          pinned={sidebarPinned || isSidebarOpen} 
          onPinToggle={handlePinToggle}
          fontSizeAdjust={fontSizeAdjust}
          isHovered={sidebarHovered}
          onHoverChange={setSidebarHovered}
        />
      </motion.div>
      
      <main className="flex-1 flex flex-col min-w-0 h-full relative overflow-hidden">
        {/* Apple-like Glassmorphic Top Nav Bar */}
        <header className={`h-16 flex-shrink-0 border-b flex items-center justify-between px-4 lg:px-8 sticky top-0 z-30 transition-colors duration-200 backdrop-blur-md ${
          theme === 'dark' 
            ? 'bg-black/70 border-[#1C1C1E] text-white' 
            : 'bg-white/80 border-[#E5E5EA] text-[#1C1C1E]'
        }`}>
          <div className="flex items-center gap-3 lg:gap-6">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors"
            >
              <Menu size={22} />
            </button>
            
            {/* Spotlight-inspired Capsule Search */}
            <div 
              title="Type a search query to filter active loads, customers, or routes"
              className={`hidden sm:flex items-center gap-3 px-4 py-2 rounded-full w-48 lg:w-80 border focus-within:ring-2 focus-within:ring-blue-500/10 focus-within:border-blue-500 transition-all ${
                theme === 'dark' ? 'bg-[#1C1C1E]/50 border-[#2D2D2D]' : 'bg-slate-100/80 border-slate-200/80'
              }`}
            >
              <Search size={14} className="text-slate-400 shrink-0" />
              <input 
                type="text" 
                placeholder="Search operational records..." 
                className="bg-transparent border-none outline-none text-[13px] w-full placeholder-slate-400 font-sans" 
              />
            </div>
            
            <div className="hidden sm:flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500"></span>
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 tracking-wide uppercase select-none">
                Live Data Link
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 lg:gap-6">
            {/* Live Font Zoom Slider */}
            <div 
              className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-full border bg-slate-50 dark:bg-[#121214] border-slate-200/60 dark:border-[#2C2C2E] min-w-[170px] select-none"
              title="Adjust visual scale dynamically"
            >
              <span className="text-[10px] font-semibold text-slate-400">A</span>
              <input 
                type="range"
                min="-2"
                max="8"
                value={fontSizeAdjust}
                onChange={handleFontSizeChange}
                className="w-full h-1 bg-slate-200 dark:bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">A</span>
              {fontSizeAdjust !== 0 && (
                <span className="text-[9px] font-mono font-semibold text-blue-500 dark:text-blue-400">
                  {fontSizeAdjust > 0 ? `+${fontSizeAdjust}px` : `${fontSizeAdjust}px`}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 lg:gap-4 lg:pl-4 lg:border-l border-slate-200/60 dark:border-[#2C2C2E]">
              <button 
                title="Active alerts and system notifications"
                className="relative p-1.5 rounded-lg text-slate-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
              >
                <Bell size={18} />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              
              <button 
                title="Open GridTMS AI assistant"
                onClick={() => navigate('ai')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 dark:hover:text-blue-400 transition-colors"
              >
                <HelpCircle size={18} />
              </button>
            </div>
          </div>
        </header>

        {/* Core Content Body with Fluid margins */}
        <section className={`flex-1 overflow-y-auto overflow-x-hidden p-4 lg:p-8 transition-colors duration-200 ${
          theme === 'dark' ? 'bg-black text-slate-100' : 'bg-[#F2F2F7] text-slate-900'
        }`}>
          <div className="max-w-7xl mx-auto h-full">
            {renderView()}
          </div>
        </section>

        {/* Minimal macOS Status Line */}
        <footer className={`h-8 flex-shrink-0 border-t px-4 lg:px-8 flex items-center justify-between text-[11px] text-slate-400 dark:text-zinc-500 transition-colors duration-200 select-none ${
          theme === 'dark' ? 'bg-black border-[#1C1C1E]' : 'bg-white border-[#E5E5EA]'
        }`}>
          <div>
            {companySettings.carrierName} — Version 1.0.4
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> 
              Operational Cloud Active
            </span>
          </div>
        </footer>
      </main>
    </div>
  );
}

export default function App() {"""

# Replace from `return (` to `export default function App()`
pattern = r"  return \(\n    <div\s+className=\{`flex min-h-screen.*export default function App\(\) \{"
content = re.sub(pattern, main_structure, content, flags=re.DOTALL)

with open('frontend/src/App.tsx', 'w') as f:
    f.write(content)
