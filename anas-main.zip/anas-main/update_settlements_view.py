import re

with open('frontend/src/views/SettlementsView.tsx', 'r') as f:
    content = f.read()

content = content.replace(
    "const { loads, drivers, recurringRules, addRecurringRule, updateRecurringRule, deleteRecurringRule } = useData();",
    "const { loads, drivers, recurringRules, addRecurringRule, updateRecurringRule, deleteRecurringRule, navigationIntent, setNavigationIntent } = useData();\n\n  useEffect(() => {\n    if (navigationIntent && navigationIntent.view === 'settlements') {\n      if (navigationIntent.searchQuery) {\n        setSearchQuery(navigationIntent.searchQuery);\n      }\n      setNavigationIntent(null);\n    }\n  }, [navigationIntent, setNavigationIntent]);"
)

with open('frontend/src/views/SettlementsView.tsx', 'w') as f:
    f.write(content)
