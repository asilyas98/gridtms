const fs = require('fs');
let code = fs.readFileSync('frontend/src/views/DispatchView.tsx', 'utf8');

// Add hoveredDriverId state to CalendarSection
code = code.replace(
  `const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];`,
  `const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const [hoveredDriverId, setHoveredDriverId] = React.useState<string | null>(null);`
);

// Add onMouseEnter/onMouseLeave to driver row and only show phantom if hovered
code = code.replace(
  `if (isAssigningLoad && assigningLoad) {`,
  `if (isAssigningLoad && assigningLoad && hoveredDriverId === driver.id) {`
);

code = code.replace(
  `key={driver.id}
                  onClick={() => {`,
  `key={driver.id}
                  onMouseEnter={() => setHoveredDriverId(driver.id)}
                  onMouseLeave={() => setHoveredDriverId(null)}
                  onClick={() => {`
);

// Implement horizontal layout calculation inside days.map
code = code.replace(
  `{days.map((day, dIdx) => {
                    const dayBlocks = rowSchedules.filter((s: ScheduleBlock) => s.day === dIdx);
                    
                    return (
                      <div key={\`\${driver.id}-\${dIdx}\`} className="flex-1 border-r border-slate-200 dark:border-[#2C2C2E] last:border-r-0 relative overflow-hidden" 
                           style={{ backgroundColor: dIdx % 2 === 0 ? 'transparent' : 'rgba(148, 163, 184, 0.03)' }}>
                        <div className="absolute inset-0 flex pointer-events-none opacity-20 dark:opacity-10">
                           {[...Array(6)].map((_, i) => (
                             <div key={i} className="flex-1 border-r border-slate-300 dark:border-[#2C2C2E]"></div>
                           ))}
                        </div>
                        {dayBlocks.map((block: ScheduleBlock) => {
                          const topPct = (block.startHour / 24) * 100;
                          const heightPct = (block.duration / 24) * 100;`,
  `{days.map((day, dIdx) => {
                    const dayBlocks = rowSchedules.filter((s: ScheduleBlock) => s.day === dIdx);
                    
                    // Calculate horizontal positions to prevent overlapping
                    dayBlocks.sort((a, b) => a.startHour - b.startHour);
                    const columns: ScheduleBlock[][] = [];
                    dayBlocks.forEach(block => {
                      let placed = false;
                      for (const col of columns) {
                        const overlaps = col.some(b => {
                          const bStart = b.startHour;
                          const bEnd = b.startHour + b.duration;
                          const start = block.startHour;
                          const end = block.startHour + block.duration;
                          return (start < bEnd && end > bStart);
                        });
                        if (!overlaps) {
                          col.push(block);
                          placed = true;
                          break;
                        }
                      }
                      if (!placed) {
                        columns.push([block]);
                      }
                    });
                    
                    const layoutMap = new Map();
                    columns.forEach((col, colIndex) => {
                      col.forEach(block => {
                        layoutMap.set(block.id, { colIndex, colCount: columns.length });
                      });
                    });
                    
                    return (
                      <div key={\`\${driver.id}-\${dIdx}\`} className="flex-1 border-r border-slate-200 dark:border-[#2C2C2E] last:border-r-0 relative overflow-hidden" 
                           style={{ backgroundColor: dIdx % 2 === 0 ? 'transparent' : 'rgba(148, 163, 184, 0.03)' }}>
                        <div className="absolute inset-0 flex pointer-events-none opacity-20 dark:opacity-10">
                           {[...Array(6)].map((_, i) => (
                             <div key={i} className="flex-1 border-r border-slate-300 dark:border-[#2C2C2E]"></div>
                           ))}
                        </div>
                        {dayBlocks.map((block: ScheduleBlock) => {
                          const topPct = (block.startHour / 24) * 100;
                          const heightPct = (block.duration / 24) * 100;
                          
                          const layout = layoutMap.get(block.id) || { colIndex: 0, colCount: 1 };
                          const leftPct = (layout.colIndex / layout.colCount) * 100;
                          const widthPct = (1 / layout.colCount) * 100;`
);

// Update className and style of the rendered block
code = code.replace(
  `className={\`absolute left-[3px] right-[3px] rounded-md transition-all duration-200 hover:scale-[1.02] hover:z-30 flex flex-col justify-center overflow-hidden z-20 border \${bgClass} \${block.id.startsWith('load__') ? 'cursor-pointer' : ''}\`}
                               style={{ top: \`\${topPct}%\`, height: \`\${heightPct}%\` }}`,
  `className={\`absolute rounded-md transition-all duration-200 hover:scale-[1.02] hover:z-30 flex flex-col justify-center overflow-hidden z-20 border \${bgClass} \${block.id.startsWith('load__') ? 'cursor-pointer' : ''}\`}
                               style={{ 
                                 top: \`\${topPct}%\`, 
                                 height: \`\${heightPct}%\`,
                                 left: \`calc(\${leftPct}% + 1px)\`,
                                 width: \`calc(\${widthPct}% - 2px)\`
                               }}`
);

fs.writeFileSync('frontend/src/views/DispatchView.tsx', code);
