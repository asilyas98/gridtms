import re

with open('frontend/src/views/LocationsView.tsx', 'r') as f:
    content = f.read()

pattern = r"React\.useEffect\(\(\) => \{\n\s*if \(navigationIntent && navigationIntent\.view === 'locations' && navigationIntent\.action === 'create'\) \{\n\s*setShowCreationMode\(true\);\n\s*if \(navigationIntent\.returnTo\) setLocalIntent\(navigationIntent\);\n\s*setNavigationIntent\(null\);\n\s*\}\n\s*\}, \[navigationIntent, setNavigationIntent\]\);"

replacement = """React.useEffect(() => {
    if (navigationIntent && navigationIntent.view === 'locations') {
      if (navigationIntent.action === 'create') {
        setShowCreationMode(true);
        if (navigationIntent.returnTo) setLocalIntent(navigationIntent);
      }
      if (navigationIntent.searchQuery) {
        setSearchTerm(navigationIntent.searchQuery);
      }
      setNavigationIntent(null);
    }
  }, [navigationIntent, setNavigationIntent]);"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)

with open('frontend/src/views/LocationsView.tsx', 'w') as f:
    f.write(content)
