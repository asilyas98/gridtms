import re

with open('frontend/src/views/AssetsView.tsx', 'r') as f:
    content = f.read()

pattern = r"(React\.useEffect\(\(\) => \{\n\s*if \(navigationIntent && navigationIntent\.view === 'assets'\) \{)(.*?)(setNavigationIntent\(null\);\n\s*\}\n\s*\}, \[navigationIntent, drivers, trucks, setNavigationIntent\]\);)"
replacement = r"""\1\2
      if (navigationIntent.searchQuery) {
        if (navigationIntent.tab === 'Drivers' || navigationIntent.tab === 'Trucks' || navigationIntent.tab === 'Units') {
          setActiveTab(navigationIntent.tab === 'Trucks' ? 'Units' : 'Drivers');
        }
        setSearchQuery(navigationIntent.searchQuery);
      }
      \3"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)

with open('frontend/src/views/AssetsView.tsx', 'w') as f:
    f.write(content)
